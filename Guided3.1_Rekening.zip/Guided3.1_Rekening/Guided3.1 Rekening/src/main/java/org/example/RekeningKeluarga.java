package org.example;

public class RekeningKeluarga extends Rekening {

    public RekeningKeluarga(Nasabah nasabah, int saldo) {
        super(nasabah, saldo);
    }

    public RekeningKeluarga(Nasabah nasabah) {
        super(nasabah);
    }

    @Override
    public void penyetoran(int jumlah) {

        Double hasilBunga = jumlah * 0.05;
        super.penyetoran(jumlah+Integer.parseInt(String.valueOf(hasilBunga)));
    }

    @Override
    public void penarikan(int jumlah) {
        super.penarikan(jumlah);
    }
}
