package org.example;

public class RekeningUtama  extends Rekening {
    public RekeningUtama(Nasabah nasabah, int saldo) {
        super(nasabah, saldo);
    }

    public RekeningUtama(Nasabah nasabah) {
        super(nasabah);
    }

    @Override
    public void penyetoran(int jumlah) {
        Double hasilBunga = jumlah * 0.05;
        super.penyetoran(jumlah+hasilBunga.intValue());
    }

    @Override
    public void penarikan(int jumlah) {
        if (jumlah < 3000000){
            if (getSaldo() >= jumlah+5000) {
                super.penarikan(jumlah+5000);
            }
        }

    }
}
