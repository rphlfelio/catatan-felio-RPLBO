package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Nasabah manusia1 = new Nasabah("Odi","mahasiswa", "Wates");
        RekeningSyariah rekening1 = new RekeningSyariah(manusia1, 1000000);
        RekeningUtama rekening2 = new RekeningUtama(manusia1, 1000000);

        System.out.println(manusia1.getNama() + " Saldonya di rekening syariah "+ rekening1.getSaldo());
        rekening1.penarikan(100000);
        System.out.println(manusia1.getNama() + " Saldonya di rekening syariah "+ rekening1.getSaldo());

        System.out.println(manusia1.getNama() + " Saldonya di rekening utama "+ rekening2.getSaldo());
        rekening2.penarikan(100000);
        System.out.println(manusia1.getNama() + " Saldonya di rekening utama "+ rekening2.getSaldo());

        rekening2.penyetoran(100000);
        System.out.println(manusia1.getNama() + " Saldonya di rekening utama "+ rekening2.getSaldo());
    }
}