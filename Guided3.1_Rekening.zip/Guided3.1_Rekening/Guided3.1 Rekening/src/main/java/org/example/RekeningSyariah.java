package org.example;

public class RekeningSyariah extends Rekening {

    public RekeningSyariah(Nasabah nasabah, int saldo) {
        super(nasabah, saldo);
    }

    public RekeningSyariah(Nasabah nasabah) {
        super(nasabah);
    }

    @Override
    public void penyetoran(int jumlah) {
        super.penyetoran(jumlah);
    }

    @Override
    public void penarikan(int jumlah) {
        if (jumlah > 100000){
            jumlah += 1000;
        }
        if (getSaldo() < jumlah){
            System.out.println("Saldo tidak cukup");
        }
        else {
            super.penarikan(jumlah);
        }

    }

    public void sedekah(int jumlah){
        if (jumlah <= getSaldo()){
            setSaldo(getSaldo() - jumlah);
        }
    }
}
