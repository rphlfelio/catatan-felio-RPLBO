package org.example;

public class RekeningTambahan extends Rekening {
    public RekeningTambahan(Nasabah nasabah, int saldo) {
        super(nasabah, saldo);
    }

    public RekeningTambahan(Nasabah nasabah) {
        super(nasabah);
    }

    @Override
    public void penyetoran(int jumlah) {

        super.penyetoran(jumlah);
    }

    @Override
    public void penarikan(int jumlah) {
        if (jumlah < 500000){
            if (getSaldo() >= jumlah+5000) {
                super.penarikan(jumlah+5000);
            }
        }
    }
}
