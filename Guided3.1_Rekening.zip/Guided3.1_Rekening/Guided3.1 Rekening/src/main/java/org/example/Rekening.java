package org.example;

public class Rekening {
    private Nasabah nasabah;
    private int saldo;


    public Rekening(Nasabah nasabah, int saldo) {
        this.nasabah = nasabah;
        this.saldo = saldo;
    }

    public Rekening(Nasabah nasabah) {
        this.nasabah = nasabah;
    }

    public void penyetoran(int jumlah){
        if (jumlah > 0){
            saldo += jumlah;
        }
    }

    public void penarikan(int jumlah){
        if (saldo >= jumlah){
            saldo -= jumlah;
        }
    }

    public Nasabah getNasabah() {
        return nasabah;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setNasabah(Nasabah nasabah) {
        this.nasabah = nasabah;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
}
