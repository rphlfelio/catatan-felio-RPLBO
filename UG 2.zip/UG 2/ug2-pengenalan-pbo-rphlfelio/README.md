[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/v1bX45GA)
<h1 style="text-align: center;">Minggu 2: Perkenalan PBO</h1>

<div style="display: flex; justify-content: center; align-items: center; flex-direction: column;">
    <div style="
        text-align: center;
        border: 1px solid black;
        border-radius: 10px;
        width: 75%;
        padding: 10px;
        ">
        <h2>Class</h2>
        <img src="./class-mahasiswa.png">
    </div>
</div>

Kalian akan diberikan 2 buah class: Main dan Mahasiswa.

- Mahasiswa

    Lengkapilah class Mahasiswa. Class ini mempunyai komponen - komponen yang bisa dilihat di diagram di atas.  
    Buat juga sebuah konstruktor Mahasiswa yang menerima parameter: 

    - name : String 
    - kodeProdi : int 
    - angkatan : int 
    
    untuk properti <b>prodi</b> pada class Mahasiswa, kalian isi sendiri sesuai dengan kode pada parameter kodeProdi yang diberikan pada konstruktor. 
    Biar lebih mudah, untuk kedokteran 61 dan untuk informatika 71. Hanya 2 prodi ini saja.
    Buat juga getter setternya.

- Main
    Untuk kelas ini, tujuan utama kalian adalah menerima input dari user berupa nama dan nim. Tenang saja, sudah disediakan oleh admin. Kemudian, dari nama dan nim tersebut, buatlah sebuah objek Mahasiswa. Kemudian, masukkan objek tersebut ke dalam fungsi printMahasiswa yang sudah disediakan oleh admin. 

    <img src="./printMahasiswa.png">

## OUTPUT
![](out1.png)

![alt text](image.png)
