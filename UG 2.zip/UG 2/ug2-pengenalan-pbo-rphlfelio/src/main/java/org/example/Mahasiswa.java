package org.example;

public class Mahasiswa  {
    String name;
    String prodi;
    int kodeProdi;
    int angkatan;

    public Mahasiswa(String name,int kodeProdi, int angkatan) {
        this.name = name;
        this.kodeProdi = kodeProdi;
        this.angkatan = angkatan;

        if (kodeProdi == 71)
            this.prodi = "Informatika";
        else
            this.prodi = "Kedokteran";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProdi() {
        return prodi;
    }

    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public int getKodeProdi() {
        return kodeProdi;
    }

    public void setKodeProdi(int kodeProdi) {
        this.kodeProdi = kodeProdi;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }
}
