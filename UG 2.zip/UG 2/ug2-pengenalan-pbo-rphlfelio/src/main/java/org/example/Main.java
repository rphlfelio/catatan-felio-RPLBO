package org.example;

import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nama Anda: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan NIM Anda: ");
        String nim = scanner.nextLine();
        scanner.close();
        Mahasiswa mhs;
        // MASUKKAN KODE ANDA DI SINI
        int kodeProdi = Integer.parseInt(nim.substring(0,2));
        int angkatan = Integer.parseInt(nim.substring(2,4));
        mhs = new Mahasiswa(name,kodeProdi,angkatan);
        // JANGAN DIPRINT MANUAL! PRINT AJA PAKAI FUNGSI
        // DI BAWAH INI:
        printMahasiswa(mhs);
    }

    /*
    * Fungsi di bawah ini (printMahasiswa())
    * JANGAN DIUBAH - UBAH, ANDA HANYA PERLU MERUBAH main() FUNCTION ATAU
    * KELAS Mahasiswa
     */
    public static void printMahasiswa (Mahasiswa mhs) {
        System.out.println("Nama\t\t: " + mhs.getName());
        System.out.println("Kode Prodi\t: " + mhs.getKodeProdi());
        System.out.println("Angkatan\t: " + mhs.getAngkatan());
        System.out.println("Prodi\t\t: " + mhs.getProdi());
    }
}
