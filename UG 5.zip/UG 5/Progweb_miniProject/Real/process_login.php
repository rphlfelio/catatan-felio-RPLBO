<?php
session_start();
include 'db.php'; // Koneksi ke database

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Enkripsi password menggunakan MD5

    // Query untuk memeriksa apakah username dan password cocok
    $query = "SELECT * FROM users WHERE username=? AND password=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password); // Mengikat parameter
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Jika login berhasil, simpan username di session
        $_SESSION['username'] = $username;
        header("Location: index.html"); // Arahkan ke halaman utama
        exit();
    } else {
        echo "Login gagal. Username atau password salah.";
    }

    $stmt->close(); // Menutup statement
}
$conn->close(); // Menutup koneksi
?>