<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Cek apakah email sudah terdaftar
    $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($checkEmail) > 0) {
        echo "<script>
                alert('Email sudah terdaftar! Silakan login.');
                window.location.href = 'index.html';
              </script>";
        exit();
    }

    // Simpan data ke database
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Registrasi berhasil! Silakan login.');
                window.location.href = 'index.html';
              </script>";
        exit();
    } else {
        echo "<script>
                alert('Registrasi gagal. Coba lagi!');
                window.location.href = 'index.html';
              </script>";
    }
} else {
    http_response_code(405);
    echo "Metode tidak diizinkan.";
}
?>