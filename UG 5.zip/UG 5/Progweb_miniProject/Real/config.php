<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "job_portal";

// Koneksi ke database
$conn = mysqli_connect($servername, $username, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>