package org.example;

public class RegistorMahasiswa {
    private Storage storage;

    public RegistorMahasiswa(Storage storage) {
        this.storage = storage;
    }

    public void registerMahasiswaBaru(Mahasiswa newMhs) {
        if(storage.getMahasiswa(newMhs.getNim()) == null){
            storage.insertMahasiswa(newMhs);
            System.out.println("Mahasiswa berhasil diregis");
        }else{
            System.out.println("Gagal");
        }

    }

    public void printInformasiMahasiswa(String nim) {
        Mahasiswa mahasiswa = storage.getMahasiswa(nim);
        if(storage.getMahasiswa(nim) == null){
            System.out.println("tidak ditemukan");
            return;
        }

        System.out.println("NIM: "+mahasiswa.getNim());
        System.out.println("Nama: "+mahasiswa.getNama());
        System.out.println("Prodi: "+mahasiswa.getProdi());
    }

    public void updateMahasiswa(String nim, String name, String prodi) {
        if(storage.getMahasiswa(nim) != null){
            storage.updateMahasiswa(nim,new Mahasiswa(name,nim,prodi));
            System.out.println("berhasill update");
            return;
        }
        System.out.println("Gagal");
    }

    public void deleteMahasiswa(String nim) {
     if(storage.getMahasiswa(nim) != null){
         storage.deleteMahasiswa(nim);
         System.out.println("berhasil hapus");
         return;
     }
        System.out.println("ganemu");
    }
}
