package org.example;

import java.util.ArrayList;

public class ArrayListStorage implements Storage {
    private ArrayList<Mahasiswa> container = new ArrayList<>();

    public ArrayList<Mahasiswa> getContainer() {
        return container;
    }

    public void setContainer(ArrayList<Mahasiswa> container) {
        this.container = container;
    }

    @Override
    public void insertMahasiswa(Mahasiswa mhs) {
        Mahasiswa mhswa = getMahasiswa(mhs.getNim());
        if(mhswa == null) {
            container.add(mhs);
        }
        return;
    }

    @Override
    public Mahasiswa getMahasiswa(String nim) {
        for (Mahasiswa mahasiswa : container) {
            if(mahasiswa.getNim().equals(nim)) {
                return mahasiswa;
            }
        }
        return null;
    }

    @Override
    public void updateMahasiswa(String nim, Mahasiswa newMhs) {
        if(getMahasiswa(nim) != null) {
            Mahasiswa mhswa = getMahasiswa(nim);
            mhswa.setNim(newMhs.getNim());
            mhswa.setNama(newMhs.getNama());

        }
    }

    @Override
    public void deleteMahasiswa(String nim) {
        Mahasiswa mhswa = getMahasiswa(nim);
        if (mhswa != null){
            container.remove(mhswa);
        }
    }
}


