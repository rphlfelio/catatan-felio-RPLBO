package org.example;

import java.util.HashMap;

public class HashMapStrorage implements Storage{
    private HashMap<String, Mahasiswa> container= new HashMap<>();

    public HashMap<String, Mahasiswa> getContainer() {
        return container;
    }

    public void setContainer(HashMap<String, Mahasiswa> container) {
        this.container = container;
    }

    @Override
    public void insertMahasiswa(Mahasiswa mhs) {
        if(!container.containsKey(mhs.getNim())){
            container.put(mhs.getNim(), mhs);
        }
    }

    @Override
    public Mahasiswa getMahasiswa(String nim) {
        return container.get(nim);
    }
//        for (Mahasiswa mhs : container.values()){
//            if (mhs.getNim().equals(nim) {
//                return mhs;
//            }
//        }
//        return null;
//    }

    @Override
    public void updateMahasiswa(String nim, Mahasiswa newMhs) {
        if(container.containsKey(nim)){
            container.replace(nim, newMhs);
        }
    }

    @Override
    public void deleteMahasiswa(String nim) {
        if (container.containsKey(nim)){
            container.remove(nim);
        }
    }
}

