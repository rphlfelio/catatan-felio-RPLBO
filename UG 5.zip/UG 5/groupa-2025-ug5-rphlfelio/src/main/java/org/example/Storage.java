package org.example;

public interface Storage {
    public void insertMahasiswa(Mahasiswa mhs);
    public Mahasiswa getMahasiswa(String nim);
    public void updateMahasiswa(String nim,Mahasiswa newMhs);
    public void deleteMahasiswa(String nim);
}
