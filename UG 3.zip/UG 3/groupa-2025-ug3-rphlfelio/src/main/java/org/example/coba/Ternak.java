package org.example.coba;

public class Ternak {
    private String name;
    private boolean status;
    private double size;
    static int jumlahTernak=0;

    public Ternak(String name) {
        this.size = Double.parseDouble(name.replaceAll("[^0-9]", ""));
        this.name = name.replaceAll("[^A-Za-z]+", "");
        this.status = true;
        jumlahTernak++;
    }

    public static void setJumlahTernak(int jumlahTernak) {
        Ternak.jumlahTernak = jumlahTernak;
    }

    public static int getJumlahTernak() {
        return jumlahTernak;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }

}
