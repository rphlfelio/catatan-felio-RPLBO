package org.example.coba;

public class Ular {
    private String name;
    private Double size;
    static int jumlahKill;

    public Ular(String name) {
        this.size = Double.parseDouble(name.replaceAll("[^0-9]", ""));
        this.name = name.replaceAll("[^A-Za-z]+", "");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getSize() {
        return size;
    }

    public void setSize(Double size) {
        this.size = size;
    }

    public static int getJumlahKill() {
        return jumlahKill;
    }

    public static void setJumlahKill(int jumlahKill) {
        Ular.jumlahKill = jumlahKill;
    }
    public void bunuh(Ternak ternak) {
        Ternak.getJumlahTernak();
        int total = Ternak.getJumlahTernak();
        if(this.size >= ternak.getSize()/3) {
            if(ternak.getStatus() && Ternak.getJumlahTernak() > 0) {
                System.out.println(this.name+" berhasil makan "+ternak.getName());
                ternak.setStatus(false);
                total--;
                Ternak.setJumlahTernak(total);
                jumlahKill++;
        }else {
                System.out.println(ternak.getName()+" tidak bisa dimakan karena sudah mati");
            }

        }else {
            System.out.println("Gagal makan! size dari "+ternak.getName()+"terlalu besar");
        }
    }
}
