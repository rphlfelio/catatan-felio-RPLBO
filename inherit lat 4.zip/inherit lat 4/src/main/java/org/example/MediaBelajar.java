package org.example;

public abstract class MediaBelajar {
    protected String judul;
    protected String deskripsi;

    public MediaBelajar(String judul, String deskripsi) {
        this.judul = judul;
        this.deskripsi = deskripsi;
    }
    public abstract void tampilkan();
}
