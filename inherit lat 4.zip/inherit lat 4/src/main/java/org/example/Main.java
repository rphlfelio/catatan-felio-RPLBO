package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    MediaBelajar[] medialist = new MediaBelajar[3];

    medialist[0] = new Video("Belajar OOP Java","Memahami konsep inherit",5);
    medialist[1] = new Artikel("Pengantar inherit","artikel ini menjelaskan tentang inherit","joko purnomo");
    medialist[2] = new Kuis("Latihan OOP","Tes Pemahaman inherit",40);

        System.out.println("===Daftar media pembelajaran===\n");
        for (MediaBelajar mb : medialist) {
            mb.tampilkan();
        }
    }
}