package org.example;

public class Kuis extends MediaBelajar{
    private int jumlahSoal;

    public Kuis(String judul, String deskripsi, int jumlahSoal) {
        super(judul, deskripsi);
        this.jumlahSoal = jumlahSoal;
    }
    public void tampilkan(){
        System.out.println("[Kuis]");
        System.out.println("Judul: " + judul);
        System.out.println("Deskripsi: " + deskripsi);
        System.out.println("Jumlah Soal: " + jumlahSoal);
        System.out.println();
    }
}
