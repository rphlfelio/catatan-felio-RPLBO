package org.example;

public class Artikel extends MediaBelajar{
    private String penulis;

    public Artikel(String judul, String deskripsi, String penulis) {
        super(judul, deskripsi);
        this.penulis = penulis;
    }
//    public String tampilkan(){
//        return penulis;
//    }
    public void tampilkan(){
        System.out.println("[Artikel]");
        System.out.println("Judul: " + judul);
        System.out.println("Deskripsi: " + deskripsi);
        System.out.println("Penulis: " + penulis);
        System.out.println();
    }
}
