package org.example;

public class Video extends MediaBelajar{
    private int durasi;

    public Video(String judul, String deskripsi, int durasi) {
        super(judul, deskripsi);
        this.durasi = durasi;
    }
    @Override
    public void tampilkan(){
        System.out.println("[Video]");
        System.out.println("Judul: " + judul);
        System.out.println("Deskripsi: " + deskripsi);
        System.out.println("Durasi: " + durasi+" menit");
        System.out.println();
    }

}
