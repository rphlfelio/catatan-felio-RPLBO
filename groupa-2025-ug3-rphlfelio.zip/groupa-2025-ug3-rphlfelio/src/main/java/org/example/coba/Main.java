package org.example.coba;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String ketUlar1 = "Python20";
        String ketUlar2 = "BlackMamba30";
        String ketUlar3 = "Anaconda50";

        String ketTernak1 = "Sapi100";
        String ketTernak2 = "Domba70";
        String ketTernak3 = "Ayam40";

        //TODO: MASUKKAN KODE ANDA DI SINI UNTUK MEMBUAT OBJECT DENGAN KETERANGAN SESUAI STRING DIATAS
        Ular ular1 = new Ular(ketUlar1);
        Ular ular2 = new Ular(ketUlar2);
        Ular ular3 = new Ular(ketUlar3);

        Ternak ternak1 = new Ternak(ketTernak1);
        Ternak ternak2 = new Ternak(ketTernak2);
        Ternak ternak3 = new Ternak(ketTernak3);

        // JANGAN DIPRINT MANUAL! PRINT AJA PAKAI FUNGSI
        // DI BAWAH INI:
        printPerburan(ular1,ular2,ular3,ternak1,ternak2,ternak3);
    }


    /*
     * Fungsi di bawah ini (printPerburan())
     * JANGAN DIUBAH - UBAH, ANDA HANYA PERLU MERUBAH main() FUNCTION dan
     * KELAS Ular serta Ternak
     */

    public static void printPerburan(Ular ular1, Ular ular2, Ular ular3, Ternak ternak1, Ternak ternak2, Ternak ternak3) {
        System.out.println();
        ular1.bunuh(ternak1);
        ular1.bunuh(ternak2);
        ular1.bunuh(ternak3);
        System.out.println("Ular telah membunuh : "+Ular.getJumlahKill()+" ternak");
        System.out.println("Ternak yang masih hidup tersisa : "+Ternak.getJumlahTernak());
        System.out.println();


        ular2.bunuh(ternak1);
        ular2.bunuh(ternak2);
        ular2.bunuh(ternak3);
        System.out.println("Ular telah membunuh : "+Ular.getJumlahKill()+" ternak");
        System.out.println("Ternak yang masih hidup tersisa : "+Ternak.getJumlahTernak());
        System.out.println();

        ular3.bunuh(ternak1);
        ular3.bunuh(ternak2);
        ular3.bunuh(ternak3);
        System.out.println("Ular telah membunuh : "+Ular.getJumlahKill()+" ternak");
        System.out.println("Ternak yang masih hidup tersisa : "+Ternak.getJumlahTernak());
        System.out.println();
    }
}