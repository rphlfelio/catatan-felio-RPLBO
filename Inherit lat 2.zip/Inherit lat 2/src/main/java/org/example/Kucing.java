package org.example;

public class Kucing extends Hewan {
    private String warna;

    public Kucing(String nama, int umur, String warna) {
        super(nama, umur);
        this.warna = warna;
    }

    @Override
    public void suara() {
        System.out.println("Meong!");
    }

    @Override
    public void info() {
        super.info();
        System.out.println("Jenis: Kucing");
        System.out.println("Warna: " + warna);
        suara();
    }
}

