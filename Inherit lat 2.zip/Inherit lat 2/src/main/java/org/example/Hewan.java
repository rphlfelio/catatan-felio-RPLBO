package org.example;

public abstract class Hewan {
    protected String nama;
    protected int umur;

    public Hewan(String nama, int umur) {
        this.nama = nama;
        this.umur = umur;
    }

    public abstract void suara();

    public void info() {
        System.out.println("Nama Hewan: " + nama);
        System.out.println("Umur: " + umur + " tahun");
    }
}

