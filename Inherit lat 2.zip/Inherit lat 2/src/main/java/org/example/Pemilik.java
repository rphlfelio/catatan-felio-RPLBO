package org.example;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class Pemilik {
    private String nama;
    private List<Hewan> daftarHewan;

    public Pemilik(String nama) {
        this.nama = nama;
        this.daftarHewan = new ArrayList<>();
    }

    public void tambahHewan(Hewan h) {
        daftarHewan.add(h);
    }

    public void tampilkanHewan() {
        System.out.println("=== Daftar Hewan milik " + nama + " ===");
        for (Hewan h : daftarHewan) {
            h.info();
            System.out.println("--------------------------");
        }
    }
}

