package org.example;

import javax.swing.*;

public class Anjing extends Hewan {
    private String ras;

    public Anjing(String nama, int umur, String ras) {
        super(nama, umur);
        this.ras = ras;
    }

    @Override
    public void suara() {
        System.out.println("Guk!");
    }

    @Override
    public void info() {
        super.info();
        System.out.println("Jenis: Anjing");
        System.out.println("Ras: " + ras);
        suara();
    }
}

