package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Pemilik pemilik = new Pemilik("Andi");

        Kucing kucing1 = new Kucing("Mimi", 2, "Putih");
        Anjing anjing1 = new Anjing("Buddy", 3, "Golden Retriever");

        pemilik.tambahHewan(kucing1);
        pemilik.tambahHewan(anjing1);

        pemilik.tampilkanHewan();
    }
}
