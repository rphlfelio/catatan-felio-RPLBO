package org.ug4.soal1;

import java.util.ArrayList;

public class Bus extends Vehicle{
    private double profit;
    private String[] route;
    private double fares;

    public Bus(String name, Driver driver, String[] route, double fares) {
        setName(name);
        setDriver(driver);
        setRoute(route);
        setFares(fares);
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public String[] getRoute() {
        return route;
    }

    public void setRoute(String[] route) {
        this.route = route;
    }

    public double getFares() {
        return fares;
    }

    public void setFares(double fares) {
        this.fares = fares;
    }
    public void dropPassengers(String lokasi, Passenger passenger) {
        if (!lokasi.equalsIgnoreCase(passenger.getDestiny())) {
            return;
        }
        if (getPassengers().contains(passenger)) {
            getPassengers().remove(passenger);
        }
        System.out.println(passenger.getName()+" Turun di " + lokasi);
    }
    public String cancelOrder(Passenger passenger) {
        passenger.setDestiny(null);
        if (getPassengers().contains(passenger)) {
            getPassengers().remove(passenger);
        }

        return null;
    }
    public void topUpBalance(double uang, Passenger passenger) {
        passenger.setBalance(passenger.getBalance() + uang);
    }
    public boolean checkPassengersBalance(Passenger passenger) {
        if (passenger.getBalance() < fares) {
            return false;
        }
        return true;
    }
    public boolean proceedOrder(String lokasi, Passenger passenger) {
        if (!checkPassengersBalance(passenger)) {
            return false;
        }
        boolean res = takePassengers(passenger);
        if (!res) {
            return false;
        }
        setProfit(fares + profit);
        passenger.setDestiny(lokasi);
        passenger.setBalance(passenger.getBalance() - fares);
        return true;

    }


}
