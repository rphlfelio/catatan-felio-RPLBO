package org.ug4.soal1;

public class Driver extends Person {
    private String licenseID;

    public Driver(String name, String gender, int age, String licenseID) {
        super(name, gender, age);
        this.licenseID = licenseID;
    }

    public String getLicenseID() {
        return licenseID;
    }

    public void setLicenseID(String licenseID) {
        this.licenseID = licenseID;
    }
}
