package org.ug4.soal1;

import java.util.ArrayList;

public class Vehicle {
    private  String name;
    private int maxCapacity = 25;
    private Driver driver;
    private ArrayList<Passenger> passengers = new ArrayList<>();
    private int usedCapacity;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public ArrayList<Passenger> getPassengers() {
        return passengers;
    }

    public void setPassengers(ArrayList<Passenger> passengers) {
        this.passengers = passengers;
    }

    public int getUsedCapacity() {
        return passengers.size();
    }

    public void addUsedCapacity(int usedCapacity) {
        this.usedCapacity = usedCapacity;
    }

    public boolean takePassengers(Passenger passenger) {
        if (usedCapacity >= maxCapacity) {
            return false;
        }
        passengers.add(passenger);
        usedCapacity++;
        return true;
    }
}

