package org.ug4.soal1;

public class Passenger extends Person {
    private String email;
    private String destiny;
    private double balance;

    public Passenger(String name, String gender, int age, String email, double balance) {
        super(name, gender, age);
        this.email = email;
        this.balance = balance;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDestiny() {
        return destiny;
    }

    public void setDestiny(String destiny) {
        this.destiny = destiny;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
