package org.ug4.soal1;

import java.util.Objects;
import java.util.Scanner;


import java.util.Scanner;

public class Main {
    static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Passenger adit = new Passenger("Adit", "Pria", 22, "adit@gmail.com", 100000);
        Passenger surya = new Passenger("Surya", "Pria", 22, "surya@gmail.com", 20000);
        Passenger krismon = new Passenger("Krismon", "Pria", 22, "krismon@gmail.com", 100);
        Driver pakTole = new Driver("Pak Tole", "pria", 35, "LID04298");
        initiateMenu(adit, surya, krismon, pakTole);
    }

    public static void initiateMenu(Passenger penumpang1, Passenger penumpang2, Passenger penumpang3, Driver driver1) {
        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        Bus dutaBus = new Bus("Duta Bus",driver1, routes, 15000);

        System.out.println("Duta Bus");
        menu(penumpang1, dutaBus);
        menu(penumpang2, dutaBus);
        menu(penumpang3, dutaBus);

        //pengecekan pada setiap pemberhentian bus
        for (int i = 0; i < 3; i++) {
            System.out.println("Pemberhentian ke " + (i + 1) + " telah sampai pada " + dutaBus.getRoute()[i]);
            dutaBus.dropPassengers(dutaBus.getRoute()[i], penumpang1);
            dutaBus.dropPassengers(dutaBus.getRoute()[i], penumpang2);
            dutaBus.dropPassengers(dutaBus.getRoute()[i], penumpang3);
            System.out.println("Sisa penumpang sebanyak " + dutaBus.getUsedCapacity() + " orang");
            System.out.println("============================================");
            System.out.println();
            System.out.println();
        }
        //menampilkan keuntungan yang diperoleh
        System.out.println("Keuntungan hari ini");
        System.out.println("Keuntungan sebesar : Rp " + dutaBus.getProfit() + "0;-");
    }

    public static void menu(Passenger passenger, Bus bus) {
        System.out.println("Selamat Datang Kak " + passenger.getName());

        if (bus.checkPassengersBalance(passenger)) {
            showDestination(bus, passenger);
        } else {
            topUpMenu(bus, passenger);
        }
        System.out.println("============================================\n\n\n");
    }

    public static void showDestination(
            Bus bus,
            Passenger passenger
    ) {
        String destiny;
        int i = 0;
        System.out.println("Pilihan rute perjalanan");
        for (String rute : bus.getRoute()) {
            i++;
            System.out.print(i + ". " + rute + "\n");
        }
        System.out.print("masukan destinasi perjalanan anda : ");
        destiny = scanner.nextLine();
        //mengecek apakah input sudah sesuai atau belum
        if (destiny.isEmpty()) {
            System.out.println("Anda belum memasukan tujuan");
        } else {
            boolean berhasil = false;
            for (String route : bus.getRoute()) {
                if (route.equalsIgnoreCase(destiny)) {
                    bus.proceedOrder(destiny, passenger);
                    berhasil = true;
                    break;
                }
            }
            if (!berhasil) {
                System.out.println("Maaf tujuan yang anda masukan tidak sesuai");
            }
        }
    }

    public static void topUpMenu(
            Bus bus,
            Passenger passenger
    ) {
        String choice;
        String balance;
        System.out.println("Anda ingin top up ?");
        System.out.print("jawaban anda (ya/tidak): ");
        choice = scanner.nextLine();

        if (choice.equalsIgnoreCase("ya")) {
            System.out.print("Masukan nominal top up : ");

            balance = scanner.nextLine();
            if (balance.isEmpty()) {
                System.out.println("Kamu belum memasukan nominal top up");
                System.out.println("\n\n");
            } else {
                bus.topUpBalance(Double.valueOf(balance), passenger);
                showDestination(bus, passenger);
            }
        } else if (choice.equalsIgnoreCase("tidak")) {
            bus.cancelOrder(passenger);
        } else {
            System.out.println("Input yang anda masukan salah");
            System.out.println("\n\n");
        }
    }
}
