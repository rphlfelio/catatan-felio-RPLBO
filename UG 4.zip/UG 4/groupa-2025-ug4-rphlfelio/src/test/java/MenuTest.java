import org.junit.jupiter.api.Test;
import org.ug4.soal1.Bus;
import org.ug4.soal1.Driver;
import org.ug4.soal1.Passenger;

import static org.junit.jupiter.api.Assertions.*;


public class MenuTest {
    @Test
    public void testMenuSufficientBalance() { //mengecek jika saldo pengguna lebih dari 15000 (fares)
        boolean hasil = false;
        // Arrange
        Driver driver1 = new Driver("Pak Nanang", "pria", 35, "LID04298");
        Passenger passenger1 = new Passenger("Andy", "Pria",22,"andy@gmail.com", 200000);
        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        Bus dutaBus = new Bus("Duta Bus", driver1, routes, 15000);

        if (dutaBus.checkPassengersBalance(passenger1)) {
            hasil = true;
        }
        assertTrue(hasil);
    }

    @Test
    public void testMenuInSufficientBalance() { //mengecek jika saldo pengguna kurang dari 15000 (fares)
        boolean hasil = false;
        // Arrange
        Driver driver1 = new Driver("Pak Nanang", "pria", 35, "LID04298");
        Passenger passenger1 = new Passenger("Andy", "Pria",22,"andy@gmail.com", 100);
        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        Bus dutaBus = new Bus("Duta Bus", driver1,routes, 15000);

        if (dutaBus.checkPassengersBalance(passenger1)) {
            hasil = true;
        }
        assertFalse(hasil);
    }
}
