import org.junit.jupiter.api.Test;
import org.ug4.soal1.Bus;
import org.ug4.soal1.Driver;
import org.ug4.soal1.Passenger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class InitiateMenuTest {
    @Test
    public void testInitiateMenu() {
        //buat objek passenger dan driver
        Passenger penumpang1 = new Passenger("Adit", "Pria", 22, "adit@gmail.com", 100000);
        Passenger penumpang2 = new Passenger("Surya", "Pria", 22, "surya@gmail.com", 20000);
        Passenger penumpang3 = new Passenger("Krismon", "Pria", 22, "krismon@gmail.com", 10000);
        Driver driver1 = new Driver("Pak Tole", "pria", 35, "LID04298");

        //periksa apakah tiga penumpang dan satu pengemudi berhasil disimpan di objek Bus
        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        Bus dutaBus = new Bus("Duta Bus", driver1, routes, 15000);
        assertTrue(dutaBus.takePassengers(penumpang1));
        assertTrue(dutaBus.takePassengers(penumpang2));
        assertTrue(dutaBus.takePassengers(penumpang3));
        assertEquals(3, dutaBus.getUsedCapacity());
    }
}
