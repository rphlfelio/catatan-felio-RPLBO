import org.junit.jupiter.api.Test;
import org.ug4.soal1.Bus;
import org.ug4.soal1.Driver;
import org.ug4.soal1.Main;
import org.ug4.soal1.Passenger;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TopUpMenuTest {

    @Test
    public void testTopUpMenu() {
        Driver driver1 = new Driver("Pak Nanang", "pria", 35, "LID04298");
        Passenger passenger1 = new Passenger("Andy", "Pria",22,"andy@gmail.com", 0);
        Passenger passenger2 = new Passenger("Anang", "Pria",22,"anang@gmail.com", 0);
        Passenger passenger3 = new Passenger("Anjas", "Pria",22,"anjas@gmail.com", 0);
        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        Bus dutaBus = new Bus("Duta Bus", driver1, routes, 15000);

        // Test case 1: Memasukkan input kosong
        String input = "ya\n\ntidak lah\nya\n100000\n\n";
        double balance1 = 0.0;
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        Main.topUpMenu(dutaBus, passenger1);
        assertEquals(balance1, passenger1.getBalance(), 0.001);

        // Test case 2: Memasukkan input yang salah
        Main.topUpMenu(dutaBus, passenger2);
        assertEquals(0.0, passenger2.getBalance(), 0.001);

        // Test case 3: Memasukkan input nominal top up yang valid
        double balance3 = 100000.0;
        Main.topUpMenu(dutaBus, passenger3);
        assertEquals(balance3, passenger3.getBalance(), 0.001);
    }

}



