
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.ug4.soal1.*;

import static org.junit.jupiter.api.Assertions.*;

public class CompleteTest {

    private Bus bus;
    private Driver driver;

    @BeforeEach
    public void setUp() {
        driver = new Driver("Pak Nanang", "pria", 35, "LID04298");

        String[] routes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        bus = new Bus("UKDW Bus", driver, routes, 15000);
        bus.setMaxCapacity(25);
    }

    @Test
    public void testClassInheritance() {
        assertTrue(bus instanceof Vehicle, "Bus should inherit from Vehicle");
        assertTrue(driver instanceof Person, "Driver should inherit from Person");
        Passenger passenger = new Passenger("Test Passenger", "male", 22, "a@a.com", 10000.0);
        assertTrue(passenger instanceof Person, "Passenger should inherit from Person");
    }

    @Test
    public void testBusCapacity() {
        assertEquals(25, bus.getMaxCapacity(), "Bus capacity should be 25");
    }

    @Test
    public void testBusRoutes() {
        String[] expectedRoutes = {"Kampus UKDW", "Asrama Omah Babadan", "Asrama Teologi"};
        assertArrayEquals(expectedRoutes, bus.getRoute(), "Bus routes should match the predefined routes");
    }

    @Test
    public void testBusHasOneDriver() {
        assertNotNull(bus.getDriver(), "Bus should have a driver");
    }

    @Test
    public void testBusFareCollection() {
        Passenger passenger = new Passenger("John Doe", "male", 22, "a@a.com", 20000.0);
        bus.proceedOrder("Kampus UKDW", passenger);
        assertEquals(5000.0, passenger.getBalance(), "Passenger balance should be reduced by the fare");
        assertEquals(15000, bus.getProfit(), "Bus profit should increase by the fare");
    }

    @Test
    public void testFullBusRestriction() {
        for (int i = 0; i < 25; i++) {
            bus.takePassengers(new Passenger("Passenger " + i, "male", 22, "a@a.com", 20000.0));
        }
        assertEquals(25, bus.getUsedCapacity(), "Bus should be at full capacity");
        boolean result = bus.proceedOrder("Kampus UKDW", new Passenger("Extra Passenger", "male", 22, "a@a.com", 20000.0));
        assertFalse(result, "Bus should not accept more passengers when at full capacity");
    }

    @Test
    public void testInsufficientBalanceHandling() {
        Passenger passenger = new Passenger("Jane Doe", "male", 22, "a@a.com", 5000.0);
        boolean result = bus.proceedOrder("Kampus UKDW", passenger);
        assertFalse(result, "Passenger should not be able to board with insufficient balance");
        assertEquals(5000.0, passenger.getBalance(), "Passenger balance should remain unchanged");
    }

    @Test
    public void testPassengerTakeAndDropOff() {
        Passenger passenger = new Passenger("Jane Doe", "male", 22, "a@a.com", 50000.0);
        bus.proceedOrder("Asrama Omah Babadan", passenger);
        assertTrue(bus.getPassengers().contains(passenger), "Passenger should be in the bus after boarding");
        bus.dropPassengers("Asrama Omah Babadan", passenger);
        assertFalse(bus.getPassengers().contains(passenger), "Passenger should be removed from the bus at the destination");
    }

    @Test
    public void testOrderProcessing() {
        Passenger passenger = new Passenger("Jane Doe", "male", 22, "a@a.com", 50000.0);
        double initialBalance = passenger.getBalance();
        double initialProfit = bus.getProfit();

        boolean result = bus.proceedOrder("Kampus UKDW", passenger);

        assertTrue(result, "Order processing should be successful");
        assertEquals(initialBalance - bus.getFares(), passenger.getBalance(), "Passenger balance should decrease by fare amount");
        assertEquals(initialProfit + bus.getFares(), bus.getProfit(), "Bus profit should increase by fare amount");
    }
}
