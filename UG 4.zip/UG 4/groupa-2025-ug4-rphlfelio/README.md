[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/TZplj-zI)
# Soal Inheritance, Abstraction, Overloading, & Overriding
UKDW akan memulai sebuah project besar bernama Duta Bus. Pengerjaan project ini dilakukan
dengan melibatkan seluruh elemen masyarakat yang ada di UKDW. Kamu sebagai mahasiswa
informatika mendapat bagian sebagai software developer. Kamu diminta untuk membuat Applikasi yang
sesuai dengan Class Diagram yang diberikan.
![img.png](diagram.png)
1. Class Bus adalah turunan dari class Vehicle, dan class driver dan passenger turunan dari class Person.
2. Class Person memiliki name, gender dan age. Sedangkan vehicle memiliki name,
   driver, usedCapacity, dan maxCapacity.
3. Setiap penumpang memiliki entitas masing-masing
4. bus mampu menampung 25 orang
5. Bus memiliki kemampuan untuk menaikkan dan menurunkan penumpang.
6. Bus memiliki 3 rute, Kampus UKDW, Asrama Omah Babadan, dan Asrama Teologi.
7. 1 bus terdapat 1 sopir.
8. Penumpang memiliki uang untuk membayar perjalanan.
9. Penumpang harus memiliki saldo yang cukup untuk melakukan 1x perjalanan.
10. Penumpang dapat memilih rute destinasi yang ingin dituju. Namun, jika input yang
    dimasukan tidak sesuai dengan 3 rute yang ada, maka akan menampilkan error “Maaf
    tujuan yang kamu masukan tidak sesuai”.
11. Bus dapat menarik biaya perjalanan kepada calon penumpang
12. Jika saldo yang dimiliki penumpang tidak cukup, maka penumpang harus top up terlebih
    dahulu melalui driver atau membatalkan perjalanan.
13. Biaya tarif bus bebas kalian tentukan.
14. Bus tidak dapat menaikan penumpang lagi jika kapasitas yang terpakai telah mencapai
    maksimal kapasitas penumpang yang tersedia.
15. Tujuan perjalanan penumpang akan disimpan Ketika order perjalanan telah diterima
    (proceed order).
16. Saldo penumpang akan dikurangi dengan tarif perjalanan yang berlaku (fares) Ketika
    order perjalanan diterima (proceed order).
17. Bus akan menurunkan penumpang sesuai tujuan rute destinasi.
18. Setiap memproses order perjalanan (proceed order), maka akan menambahkan
    keuntungan yang diperoleh bus tersebut.

**Jika program dijalankan maka akan terlihat seperti pada gambar di bawah :**  
![img.png](img.png)  
![img_1.png](img_1.png)  
![img_2.png](img_2.png)  

### Poin Penilaian (max 100 point):
1. PROGRAM BERHASIL DICOMPILE: gunakan mvn compile (Poin 15)
2. Eksekusi perintah mvn test -Dtest="InitiateMenuTest" berhasil (Poin 15)
3. Eksekusi perintah mvn test -Dtest="MenuTest" berhasil (Poin 15)
4. Eksekusi perintah mvn test -Dtest="TopUpMenuTest" berhasil (Poin 15)
5. Eksekusi perintah mvn test -Dtest="CompleteTest". 9 test berhasil semua (Poin 40)