package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    Pegawai pegawai1 = new PegawaiTetap("Aldo",71231042,500000);
    Pegawai pegawai2 = new PegawaiKontrak("Felio",71231049,7,50000);
        System.out.println("\n===pegawai1====");
    pegawai1.info();


    System.out.println("\n===pegawai2====");
    pegawai2.info();

    }
}