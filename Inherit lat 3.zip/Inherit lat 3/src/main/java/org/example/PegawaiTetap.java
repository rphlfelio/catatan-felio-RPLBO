package org.example;

public class PegawaiTetap extends Pegawai {
    private int gajiPokok;

    public PegawaiTetap(String nama, int nip, int gajiPokok) {
        super(nama, nip);
        this.gajiPokok = gajiPokok;
    }
    @Override
    public int hitungGaji() {
        return gajiPokok;

    }
    @Override
    public void info() {
        super.info();
        System.out.println("Status     : Pegawai Tetap");
        System.out.println("Gaji Pokok : " + gajiPokok);
        System.out.println("Total Gaji : " + hitungGaji());
    }
}
