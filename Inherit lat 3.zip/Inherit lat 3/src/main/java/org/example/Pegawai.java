package org.example;

public abstract class Pegawai {
    protected String nama;
    protected int nip;

    public Pegawai(String nama, int nip) {
        this.nama = nama;
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }
    public abstract int hitungGaji();

    public void info(){
        System.out.println("Nama: " + getNama());
        System.out.println("Nip: "+getNip());
    }
}
