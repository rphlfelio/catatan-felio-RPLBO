package org.example;

public class PegawaiKontrak extends Pegawai {
    private int jamKerja;
    private int upahPerJam;

    public PegawaiKontrak(String nama, int nip, int jamKerja, int upahPerJam) {
        super(nama, nip);
        this.jamKerja = jamKerja;
        this.upahPerJam = upahPerJam;
    }
    @Override
    public int hitungGaji(){
        int total = jamKerja * upahPerJam;
        return total;
    }
    @Override
    public void info(){
        super.info();
        System.out.println("Status      : Pegawai Kontrak");
        System.out.println("Jam Kerja   : " + jamKerja);
        System.out.println("Upah per Jam: " + upahPerJam);
        System.out.println("Total Gaji  : " + hitungGaji());
    }
}
