package org.ukdw.data;

public class Pemesanan {
    private String CheckOutTime;
    private int id;
    private String userEmail;
    private String checkOutDate;
    private String checkInTime;
    private int idRuangan;
    private String checkInDate;

    public Pemesanan( int id,String userEmail,int idRuangan,String checkOutTime,  String checkOutDate, String checkInTime,  String checkInDate) {
        CheckOutTime = checkOutTime;
        this.id = id;
        this.userEmail = userEmail;
        this.checkOutDate = checkOutDate;
        this.checkInTime = checkInTime;
        this.idRuangan = idRuangan;
        this.checkInDate = checkInDate;
    }

    public String getCheckOutTime() {
        return CheckOutTime;
    }

    public void setCheckOutTime(String checkOutTime) {
        CheckOutTime = checkOutTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public String getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(String checkInTime) {
        this.checkInTime = checkInTime;
    }

    public int getIdRuangan() {
        return idRuangan;
    }

    public void setIdRuangan(int idRuangan) {
        this.idRuangan = idRuangan;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }
}
