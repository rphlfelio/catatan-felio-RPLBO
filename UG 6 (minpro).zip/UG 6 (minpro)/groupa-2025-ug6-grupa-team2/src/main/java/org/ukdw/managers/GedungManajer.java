package org.ukdw.managers;

import org.ukdw.data.Gedung;

import java.util.ArrayList;

public class GedungManajer {
    private ArrayList<Gedung> gedungList;

    public GedungManajer() {
        this.gedungList = new ArrayList<>();
    }

    public boolean addGedung(String nama) {
        int id = 0;
        for (Gedung g : gedungList) {
            if (g.getId() == id) {
                return false; // ID harus unik
            }
        }
        gedungList.add(new Gedung(id, nama));
        return true;
    }

    public boolean editGedung(int id, String nama, String alamat) {
        for (Gedung g : gedungList) {
            if (g.getId() == id) {
                g.setNama(nama);
                g.setAlamat(alamat);
                return true;
            }
        }
        return false;
    }

    public boolean deleteGedung(int id) {
        return gedungList.removeIf(g -> g.getId() == id);
    }

    public ArrayList<Gedung> allGedung() {
        return new ArrayList<>(gedungList);
    }

}
