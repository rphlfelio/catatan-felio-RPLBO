package org.ukdw;
import org.ukdw.data.Ruangan;
import org.ukdw.managers.RuanganManager;


import org.ukdw.data.Pemesanan;
import org.ukdw.managers.PemesananManager;

import org.ukdw.data.Gedung;
import org.ukdw.managers.GedungManajer;


import java.util.ArrayList;

import org.ukdw.data.User;
import org.ukdw.managers.UserManager;

import java.util.List;
import java.util.Scanner;

public class RoomBookSystem {

    UserManager userManager = new UserManager(null);


    PemesananManager pemesananManager;

    private RuanganManager ruanganManager = new RuanganManager(new ArrayList<>());
    private Scanner scanner;


    public RoomBookSystem(RuanganManager ruanganManager) {
        this.ruanganManager = ruanganManager;
        this.scanner = new Scanner(System.in);
    }

    GedungManajer gedungManajer;

    public RoomBookSystem() {
        this.gedungManajer = new GedungManajer();
    }

    public void lihatSemuaDataRuangan() {
        System.out.println("Daftar Ruangan: ");
        for(Ruangan ruang : ruanganManager.allRuangan){
            System.out.println("ID: " + ruang.getId() + ", " + "Nama: " + ruang.getNama() + ", " + "ID Gedung: " + ruang.getIdGedung()  );
        }
    }

    private void editRuangan(Scanner scanner) {
        System.out.println("Masukkan ID ruangan: ");
        int idRuangan = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Masukkan nama baru ruangan: ");
        String namaBaru = scanner.nextLine();
        System.out.println("Masukkan ID Gedung baru: ");
        int idGedung = scanner.nextInt();
        scanner.nextLine();

        if(ruanganManager.editRuangan(namaBaru, idGedung, idRuangan)){
            System.out.println("Ruangan berhasil diedit: ");
        }else{
            System.out.println("Gagal mengedit ruangan");
        }
    }


    private void addRuangan(Scanner scanner) {
        System.out.println("Masukkan nama ruangan: ");
        String nama = scanner.nextLine();
        System.out.println("Masukkan id ruangan: ");
        int idRuangan = scanner.nextInt();
        scanner.nextLine();
        if(ruanganManager.addRuangan(nama, idRuangan)){
            System.out.println("Ruangan berhasil ditambahkan");
        }else{
            System.out.println("Gagal menambahkan ruangan");
        }


    }

    private void deleteRuangan(Scanner scanner) {
        System.out.println("Masukkan id ruangan     : ");
        int idRuangan = scanner.nextInt();
        scanner.nextLine();
        if(ruanganManager.deleteRuangan(idRuangan)){
            System.out.println("Ruangan berhasil dihapus");
        }else{
            System.out.println("Gagal menghapus ruangan");
        }
    }



    private void start() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Selamat datang di System pemesanan ruangan UKDW");
            System.out.println("1. Add Ruangan");
            System.out.println("2. Edit Ruangan");
            System.out.println("3. Delete Ruangan");
            System.out.println("4. Lihat Ruangan");

            System.out.println("5. Tambah Pemesanan");
            System.out.println("6. Lihat Semua Pemesanan");
            System.out.println("7. Hapus Pemesanan");
            System.out.println("8. Edit Pemesanan");
            System.out.println("0. Exit");
            System.out.println("1. Tambah Gedung");
            System.out.println("2. Lihat Semua Gedung");
            System.out.println("3. Edit Gedung");
            System.out.println("4. Hapus Gedung");




            System.out.print("Silahkan menentukan pilihan: ");
            int choice = scanner.nextInt();

            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addGedung(scanner);
                    break;
                case 2:
                    lihatSemuaDataGedung();
                    break;
                case 3:
                    editGedung(scanner);
                    break;
                case 4:
                    deleteGedung(scanner);
                    break;

                case 0:
                    exitApps();
                    return;
                case 1:
                    addRuangan(scanner);
                    return;
                case 2:
                    editRuangan(scanner);
                    return;
                case 3:
                    deleteRuangan(scanner);
                    return;
                case 4:
                    lihatSemuaDataRuangan();
                    return;

                case 5:
                    addPemesanan(scanner);
                    return;
                case 6:
                    lihatSemuaPemesanan();
                    return;
                case 7:
                    deletePemesanan(scanner);
                    return;
                case 8:
                    editPemesanan(scanner);
                    return;

                default:

                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    private void registerUser(Scanner scanner) {
        System.out.print("Masukkan nama: ");
        String nama = scanner.nextLine();
        System.out.print("Masukkan email: ");
        String email = scanner.nextLine();
        System.out.print("Masukkan password: ");
        String password = scanner.nextLine();

        if (userManager.registerUser(nama, email, password)) {
            System.out.println("Registrasi berhasil!");
        } else {
            System.out.println("Registrasi gagal. Email mungkin sudah digunakan.");
        }
    }

    private void loginUser(Scanner scanner) {
        System.out.print("Masukkan email: ");
        String email = scanner.nextLine();
        System.out.print("Masukkan password: ");
        String password = scanner.nextLine();

        if (userManager.authenticateUser(email, password)) {
            System.out.println("Login berhasil! Selamat datang, " + email);
        } else {
            System.out.println("Login gagal! Periksa kembali email dan password Anda.");
        }
    }

    private void addGedung(Scanner scanner) {
        System.out.print("Masukkan nama gedung: ");
        String namaGedung = scanner.nextLine();
        gedungManajer.addGedung(namaGedung);
        System.out.println("Gedung berhasil ditambahkan.");
    }

    private void lihatSemuaDataGedung() {
        System.out.println("Daftar Gedung:");
        gedungManajer.allGedung().forEach(System.out::println);
    }

    private void editGedung(Scanner scanner) {
        System.out.print("Masukkan nama gedung yang ingin diedit: ");
        String namaLama = scanner.nextLine();
        System.out.print("Masukkan nama baru: ");
        String namaBaru = scanner.nextLine();

        int id=0;
        Gedung gedung = new Gedung(id, namaLama);
        for (Gedung g : gedungManajer.allGedung()) {
            if (g.getNama().equals(namaLama)) {
               gedung = g;
            }
        }

        boolean success = gedungManajer.editGedung(id, namaBaru, gedung.getAlamat());
        if (success) {
            System.out.println("Gedung berhasil diperbarui.");
        } else {
            System.out.println("Gedung tidak ditemukan.");
        }
    }

    private void deleteGedung(Scanner scanner) {
        System.out.print("Masukkan nama gedung yang ingin dihapus: ");
        String namaGedung = scanner.nextLine();

        int id=0;
        Gedung gedung = new Gedung(id, namaGedung);
        for (Gedung g : gedungManajer.allGedung()) {
            if (g.getNama().equals(namaGedung)) {
                gedung = g;
            }
        }

        boolean success = gedungManajer.editGedung(id, namaGedung, gedung.getAlamat());
        if (success) {
            System.out.println("Gedung berhasil dihapus.");
        } else {
            System.out.println("Gedung tidak ditemukan.");
        }
    }

    private void exitApps() {
        System.out.println("Keluar aplikasi. Goodbye!");
        System.exit(0);
    }

    public static void main(String[] args) {
        RoomBookSystem roomBookSystem = new RoomBookSystem();
//        DBConnectionManager.createTables();
        roomBookSystem.start();
    }


    private void addPemesanan(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Masukkan id pemesanan: ");
        int id = scanner.nextInt();
        System.out.println("Masukkan userEmail: ");
        String userEmail = scanner.nextLine();
        System.out.println("Masukkan idRuangan: ");
        int idRuangan = scanner.nextInt();
        System.out.println("Masukkan checkInDate: ");
        String checkInDate = scanner.nextLine();
        System.out.println("Masukkan checkOutDate: ");
        String checkOutDate = scanner.nextLine();
        System.out.println("Masukkan checkInTime: ");
        String checkInTime = scanner.nextLine();
        System.out.println("Masukkan checkOutTime: ");
        String checkOutTime = scanner.nextLine();
        if (pemesananManager.addPemesanan(userEmail,idRuangan,checkInDate,checkOutDate,checkInTime,checkOutTime)) {
            pemesananManager = new PemesananManager();
            System.out.println("Berhasil ditambahin!!");
        }else {
            System.out.println("Pemesanan gagal ditambah!!");
        }

    }
    private void lihatSemuaPemesanan() {
        if(pemesananManager.allPemesanan.isEmpty()){
            System.out.println("Pemesanan tidak ada");
        }
        for(Pemesanan p : pemesananManager.allPemesanan){
            System.out.println(p);
        }
    }

    private void deletePemesanan(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Masukkan id: ");
        int id = scanner.nextInt();
        if (pemesananManager.deletePemesanan(id)){
            System.out.println("Pemesanan berhasil dihapus");
        } else {
            System.out.println("Pemesanan tidak ditemukan");
        }
    }
    private void editPemesanan(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Masukkan id pemesanan: ");
        int id = scanner.nextInt();
        System.out.println("Masukkan userEmail: ");
        String userEmail = scanner.nextLine();
        System.out.println("Masukkan idRuangan: ");
        int idRuangan = scanner.nextInt();
        System.out.println("Masukkan checkInDate: ");
        String checkInDate = scanner.nextLine();
        System.out.println("Masukkan checkOutDate: ");
        String checkOutDate = scanner.nextLine();
        System.out.println("Masukkan checkInTime: ");
        String checkInTime = scanner.nextLine();
        System.out.println("Masukkan checkOutTime: ");
        String checkOutTime = scanner.nextLine();
        pemesananManager.editPemesanan(userEmail, idRuangan, checkInDate, checkOutDate, checkInTime, checkOutTime);
    }


}
