package org.ukdw.data;

public class Ruangan {
    private int id;
    private String nama;
    private int idGedung;

    public Ruangan(int id, String nama, int idGedung) {
        this.id = id;
        this.nama = nama;
        this.idGedung = idGedung;
    }

    public int getIdGedung() {
        return idGedung;
    }

    public void setIdGedung(int idGedung) {
        this.idGedung = idGedung;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
