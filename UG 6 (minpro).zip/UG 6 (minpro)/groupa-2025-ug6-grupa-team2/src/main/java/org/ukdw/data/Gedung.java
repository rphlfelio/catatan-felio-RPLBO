package org.ukdw.data;

public class Gedung {
    private int id;
    private String nama;
    private String alamat;

    public void setId(int id) {
        this.id = id;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public Gedung(int id, String nama) {
        this.id = id;
        this.nama = nama;
        this.alamat = alamat;
    }

    public int getId() { return id; }
    public String getNama() { return nama; }
    public String getAlamat() { return alamat; }

}
