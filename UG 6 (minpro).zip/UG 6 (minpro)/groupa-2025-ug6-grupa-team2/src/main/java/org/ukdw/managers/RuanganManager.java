package org.ukdw.managers;

import org.ukdw.data.Ruangan;

//import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

public class RuanganManager{
//    private Connection connection;
    public List<Ruangan> allRuangan;

    public RuanganManager(List<Ruangan> allRuangan) {
        this.allRuangan = allRuangan;
    }



    public boolean deleteRuangan(int id){
        for(Iterator<Ruangan> it = allRuangan.iterator(); it.hasNext();){
            Ruangan ruang = it.next();
            if(ruang.getId() == id){
                it.remove();
                return true;
            }
        }
        return false;
    }

    public boolean editRuangan(String nama, int idGedung, int id){
        for(Ruangan ruang : allRuangan){
            if(ruang.getId() == id){
                ruang.setNama(nama);
                ruang.setIdGedung(idGedung);
                return true;
            }
        }
        return false;
    }

    public boolean addRuangan(String nama, int idGedung){
        int id = allRuangan.size() + 1;
        Ruangan ruangan = new Ruangan(id, nama, idGedung);
        allRuangan.add(ruangan);
        return true;
    }







}
