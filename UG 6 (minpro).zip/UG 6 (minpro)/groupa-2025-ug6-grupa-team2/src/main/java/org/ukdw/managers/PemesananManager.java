package org.ukdw.managers;

import org.ukdw.data.Pemesanan;

import java.util.ArrayList;
import java.util.Iterator;

public class PemesananManager {
    public ArrayList<Pemesanan> allPemesanan;
    public static int id;
    public boolean addPemesanan(String userEmail,int idRuangan,String checkInDate,String checkOutDate,String checkInTime,String checkOutTime ){
        id += 1;
        return allPemesanan.add(new Pemesanan(id,userEmail,idRuangan,checkOutTime,checkOutDate,checkInTime,checkInDate));
    }
    public boolean deletePemesanan(int id){
    Iterator<Pemesanan> iterator = allPemesanan.iterator();
    while(iterator.hasNext()){
        Pemesanan p = iterator.next();
        if(p.getId() == id){
            iterator.remove();
            return true;
        }
    }
    return false;
    }

    public boolean editPemesanan(String userEmail,int idRuangan,String checkInDate,String checkOutDate,String checkInTime,String checkOutTime ){
        for (Pemesanan p : allPemesanan) {
            if(p.getUserEmail().equals(userEmail) && p.getId() == idRuangan){
                p.setCheckInDate(checkInDate);
                p.setCheckOutDate(checkOutDate);
                return true;
            }
        }
        return false;
    }
}
